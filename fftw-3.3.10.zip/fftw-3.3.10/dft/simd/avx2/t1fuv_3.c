/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-avx2.h"
#include "../common/t1fuv_3.c"
