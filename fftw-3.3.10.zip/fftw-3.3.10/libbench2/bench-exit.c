/* not worth copyrighting */
#include "libbench2/bench.h"

/* default routine, can be overridden by user */
void bench_exit(int status)
{
     exit(status);
}
